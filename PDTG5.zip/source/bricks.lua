import "CoreLibs/object"
import "CoreLibs/graphics"
import "CoreLibs/sprites"
import "CoreLibs/timer"

local gfx <const> = playdate.graphics
	
	local bricksImage = gfx.image.new("bricks.png")
	bricksSprite = gfx.sprite.new(bricksImage)
	bricksSprite:setCollideRect( 0, 0, bricksSprite:getSize() )
	bricksSprite:setGroups(2)
	bricksSprite:setCollidesWithGroups(1)
	bricksSpriteWidth = bricksSprite:getSize()

function placeBricks()
	bricksSprite:moveTo( 0+(bricksSpriteWidth/2),128)
	bricksSprite:add()
end
