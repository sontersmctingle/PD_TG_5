import "CoreLibs/object"
import "CoreLibs/graphics"
import "CoreLibs/sprites"
import "CoreLibs/timer"

import "player.lua"


local gfx <const> = playdate.graphics
local snd <const> = playdate.sound

gravConstant = 2
termVelY = 100

--[[function doPlayerGravity()
	
	if playerSpawned == true then
	setPlayerGravity()

 
	
	playerSprite:moveWithCollisions(playerSprite.x, playerSprite.y+playerGrav)
end

   
end]]
