import "CoreLibs/graphics"
import "CoreLibs/sprites"
import "CoreLibs/timer"
import "gravity"

local gfx <const> = playdate.graphics

local playerImage = gfx.image.new("player.png")
playerSprite = gfx.sprite.new(playerImage)
playerSprite:setCollideRect( 0, 0, playerSprite:getSize() )
playerSprite:setGroups(1)
playerSprite:setCollidesWithGroups(2)
playerSpawned = false
playerGrounded = false
playerIsJumping = false

playerSpeedX = 0
playerJumpHeight = 20
--playerMomentumX = 2
playerInertiaX = 2
playerTractionX = 1


function newPlayer()
	playerSprite:moveTo( 200,120 )
	playerSprite:add()
	playerSpawned = true
	playerPrevYPos = 0
	playerCurrentYPos = playerSprite.y

	
end

function spawnPlayer()
	if playdate.buttonIsPressed( playdate.kButtonA ) and playerSpawned == false then
	newPlayer()
	end

end


function playerFacing()
	
	if facing == "RIGHT" then
	   gfx.sprite.setImageFlip(playerSprite,gfx.kImageFlippedX)
	   playerSprite:add()
	   end
	if facing == "LEFT" then
	   gfx.sprite.setImageFlip(playerSprite,gfx.kImageUnflipped)
	   playerSprite:add()
		end
end


function playerUpdateCycle()
	
	
	
	
	if playerSprite.wraps then
	local x, y, w, h = playerSprite:getBounds()
	
	if x > 400 then
	  playerSprite:moveTo(playerSprite.x - (400 + w), playerSprite.y)
	  return
	elseif x + w < 0 then
	  playerSprite:moveTo(playerSprite.x + (400 + w), playerSprite.y)
	  return
	end
end

if playerSpawned == true then	
	
	setPlayerGravity()
	
	playerPrevYPos = playerCurrentYPos
	playerSprite:moveWithCollisions(playerSprite.x, playerSprite.y+playerGrav)
	playerCurrentYPos = playerSprite.y
	if playerPrevYPos == playerCurrentYPos then
	 playerGrav = 0
 end
 
	
	playerFacing()
	
	
	collisionsArray = {playerSprite:checkCollisions(playerSprite.x, playerSprite.y+1)}
		  
	   local collisionsVal = collisionsArray[4]
	   print(collisionsArray[1],collisionsArray[2],collisionsArray[3],collisionsArray[4])
	   
	   if collisionsVal == 1 then
		  playerGrounded = true
	  else if collisionsVal == 0 then
		  playerGrounded = false
	  end
	  
	   end
	  
	
	if playdate.buttonIsPressed( playdate.kButtonLeft ) then
		if playerSpeedX < 6 then
			playerSpeedX = playerSpeedX + playerInertiaX
		elseif playerSpeedX > 6 then
			playerSpeedX = 6
		end
		
		facing = "LEFT"
	elseif playdate.buttonIsPressed(playdate.kButtonRight) then
		if playerSpeedX < 6 then
			playerSpeedX = playerSpeedX + playerInertiaX
		elseif playerSpeedX > 6 then
			playerSpeedX = 6
		end
		facing = "RIGHT"
	else
		
			if playerSpeedX > 0 then
				playerSpeedX = playerSpeedX - playerTractionX
			elseif playerSpeedX < 0 then
				playerSpeedX = 0
	end
	
	
	
	end
	if playdate.buttonIsPressed( playdate.kButtonA ) and playerCanJump == true then
	playerCanJump = false
	playerGrounded = false
	playerGrav = -playerJumpHeight
	playerIsJumping = true
	

	 end
if facing == "LEFT" then
	playerSprite:moveWithCollisions(playerSprite.x-playerSpeedX, playerSprite.y)
elseif facing == "RIGHT" then
	playerSprite:moveWithCollisions(playerSprite.x+playerSpeedX, playerSprite.y)
end

	
	 
	 if playerGrounded == true then
	   playerCanJump=true
	   
	 else playerCanJump = false
	 end
	 
	 end
end





function setPlayerGravity()
	
	if playerGrounded == false then
		if playerGrav < termVelY then
		playerGrav = (playerGrav + gravConstant)
		else
		playerGrav = termVelY
		end
		else if playerGrounded == true then
		playerGrav = 0
		playerIsJumping = false
	end
	
	
end
end	
	

