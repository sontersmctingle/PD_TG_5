import "CoreLibs/object"
import "CoreLibs/graphics"
import "CoreLibs/sprites"
import "CoreLibs/timer"

import "startup"
import "player"
import "gravity"

local gfx <const> = playdate.graphics
local snd <const> = playdate.sound

initGame()

function playdate.update()
	
	spawnPlayer()
	playerUpdateCycle()
	print(playerGrav)
	
	print(playerSpeedX)
	
	playdate.timer.updateTimers()
	gfx.sprite.update()
end