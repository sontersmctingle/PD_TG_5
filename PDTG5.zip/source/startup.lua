import "CoreLibs/object"
import "CoreLibs/graphics"
import "CoreLibs/sprites"
import "CoreLibs/timer"

local gfx <const> = playdate.graphics
local snd <const> = playdate.sound

import "bricks.lua"


function initGame()

   local stageImage = gfx.image.new("stage.png")
   stageSprite = gfx.sprite.new(stageImage)
   
   stageSprite:add()
   local w, h = stageSprite:getSize()
   stageSprite:setCollideRect( -20, 0, w+40, h )
   stageSprite:moveTo( 200,240-24 )
   stageSprite:setGroups(2)
   stageSprite:setCollidesWithGroups(1)
   
  local scoreboardImage = gfx.image.new("scorebanner.png")
	scoreboardSprite = gfx.sprite.new(scoreboardImage)
	scoreboardSprite:moveTo( 200,240-8 )
	scoreboardSprite:add()
	scoreboardSprite:setCollideRect( 0, 0, scoreboardSprite:getSize() )
	scoreboardSprite:setGroups(3)
  
  playerGrav=0
  playerSprite.wraps = 1
  
  placeBricks()

end
